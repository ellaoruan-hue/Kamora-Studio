const app = document.getElementById("app");
let currentUser = JSON.parse(localStorage.getItem("orixa_user") || "null");
let screen = "home";
let chatMessages = [];

const navItems = [
  ["home","⌂","Home"],["chat","◈","Chat"],["create","✦","Create"],["video","▶","Video"],["voice","◉","Voice"],
  ["research","⌕","Research"],["learn","▣","Learn"],["work","◆","Work"],["projects","◇","Projects"],
  ["library","▤","Library"],["settings","⚙","Settings"]
];

function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function toast(t){const d=document.createElement("div");d.className="toast";d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2200)}
function setUser(u){currentUser=u;localStorage.setItem("orixa_user",JSON.stringify(u));render()}
function auth(mode="login"){
  const signup=mode==="signup";
  app.innerHTML=`<div class="auth"><div class="auth-card">
    <div class="orb">◈</div><div class="logo">ORIXA</div><div class="tag">YOUR WORLD. POWERED BY AI.</div>
    <h1>${signup?"Create your ORIXA account":"Welcome back."}</h1>
    <p class="sub">${signup?"Let's build your AI world.":"Continue your journey with ORIXA."}</p>
    ${signup?`<div class="field"><label>First name</label><input class="input" id="name" placeholder="What should ORIXA call you?"></div>`:""}
    <div class="field"><label>Email address</label><input class="input" id="email" type="email" placeholder="Enter your email"></div>
    <div class="field"><label>Password</label><input class="input" id="password" type="password" placeholder="${signup?"Create a password":"Enter your password"}"></div>
    ${!signup?`<div style="text-align:right;margin:4px 0 18px"><button class="auth-switch" style="background:none;border:0;color:var(--gold2)" onclick="toast('Password recovery will connect to your email provider in production.')">Forgot password?</button></div>`:""}
    <button class="primary" onclick="${signup?"doSignup()":"doLogin()"}">${signup?"Create account":"Continue →"}</button>
    <div class="divider">or</div>
    <button class="ghost full" onclick="demoLogin()">Continue with Google</button>
    <button class="ghost full" style="margin-top:9px" onclick="demoLogin()">Continue with Apple</button>
    <div class="auth-switch">${signup?"Already have an account?":"Don't have an account?"} <button onclick="auth('${signup?"login":"signup"}')">${signup?"Log in":"Create one"}</button></div>
  </div></div>`;
}
async function doLogin(){const email=document.getElementById("email").value.trim();if(!email)return toast("Enter your email.");const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email})});setUser((await r.json()).user)}
async function doSignup(){const name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim();if(!name||!email)return toast("Add your name and email.");const r=await fetch("/api/auth/signup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,email})});const u=(await r.json()).user;localStorage.setItem("orixa_user",JSON.stringify(u));currentUser=u;onboarding()}
function demoLogin(){setUser({name:"Beautiful",email:"demo@orixa.ai",preferences:["Everything"]})}
function onboarding(){
 app.innerHTML=`<div class="auth"><div class="auth-card"><div class="orb">✦</div><div class="logo">ORIXA</div>
 <h1>Let's make ORIXA yours.</h1><p class="sub">What do you want ORIXA to help you with?</p>
 <div class="onboard" id="choices">${["🎨 Creating","📚 Learning","💼 Work","🎬 Content","💡 Business","🧠 Everyday help","✨ Everything"].map(x=>`<button class="choice" onclick="this.classList.toggle('selected')">${x}</button>`).join("")}</div>
 <button class="primary" onclick="finishOnboarding()">Continue →</button></div></div>`;
}
function finishOnboarding(){const prefs=[...document.querySelectorAll(".choice.selected")].map(x=>x.textContent.trim());currentUser.preferences=prefs;localStorage.setItem("orixa_user",JSON.stringify(currentUser));render()}
function shell(content){
 const name=currentUser?.name||"Beautiful";
 app.innerHTML=`<div class="app-shell"><aside class="sidebar"><div class="brand"><div class="brand-mark">◈</div><div><div class="brand-name">ORIXA</div><span class="brand-ai">AI</span></div></div>
 <nav class="nav">${navItems.map(([id,ic,label])=>`<button class="${screen===id?"active":""}" onclick="go('${id}')">${ic} <span>${label}</span></button>`).join("")}</nav>
 <div class="side-bottom"><div class="user-mini"><div class="avatar">${esc(name[0]||"O").toUpperCase()}</div><div><b>${esc(name)}</b><small>ORIXA user</small></div></div></div></aside>
 <main class="main"><div class="page">${content}</div></main></div>`;
}
function top(title,eyebrow="ORIXA AI"){return `<div class="topbar"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1></div><div class="actions"><button class="icon-btn" onclick="toast('Notifications are ready for the production backend.')">♢</button></div></div>`}
function go(s){screen=s;render()}
function render(){
 if(!currentUser)return auth("login");
 const views={home:home,chat:chat,create:create,video:video,voice:voice,research:research,learn:learn,work:work,projects:projects,library:library,settings:settings};
 shell(views[screen]?views[screen]():home());
}
function home(){const n=currentUser.name||"Beautiful";return top(`Good morning, ${esc(n)}.`,`WELCOME BACK`)+`<section class="hero"><div class="eyebrow">YOUR AI PARTNER</div><h2>Tell ORIXA what you want. We'll help you make it happen.</h2><p>Chat, create, research, learn, work and organize everything in one intelligent workspace.</p><div class="prompt"><input id="homePrompt" placeholder="Ask ORIXA anything..."><button class="send" onclick="quickChat('homePrompt')">Ask →</button></div></section>
<div class="section"><div class="section-head"><h2>What do you want to do?</h2></div><div class="grid cards-4">${[
["◈","Chat","Think through anything with ORIXA.","chat"],["✦","Create","Images, writing, ideas and more.","create"],["▶","Video Studio","Build and plan AI videos.","video"],["◉","Voice","Choose voices, accents and settings.","voice"],["⌕","Research","Turn questions into organized research.","research"],["▣","Learn","Lessons, quizzes and study plans.","learn"],["◆","Work","Plans, documents and productivity.","work"],["◇","Projects","Keep your work organized.","projects"]].map(x=>`<div class="card" onclick="go('${x[3]}')" style="cursor:pointer"><div class="tool-icon">${x[0]}</div><h3>${x[1]}</h3><p>${x[2]}</p></div>`).join("")}</div></div>
<div class="section"><div class="section-head"><h2>Recent projects</h2><button class="ghost" onclick="go('projects')">View all</button></div><div id="recentProjects" class="list">Loading...</div></div><div id="projectScript"></div>`}
async function loadProjects(){const r=await fetch("/api/projects");const ps=await r.json();const el=document.getElementById("recentProjects");if(el)el.innerHTML=ps.slice(0,4).map(p=>`<div class="list-row"><div><b>${esc(p.icon)} ${esc(p.name)}</b><div class="muted">${esc(p.type)} · ${esc(p.updated)}</div></div><button class="ghost" onclick="toast('Opening ${esc(p.name)}')">Open</button></div>`).join("")}
function quickChat(id){const v=document.getElementById(id)?.value.trim();if(!v)return;screen="chat";chatMessages.push({me:true,text:v});render();setTimeout(sendChat,100)}
async function sendChat(){const last=chatMessages.filter(x=>x.me).at(-1)?.text;if(!last)return;const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:last})});const d=await r.json();chatMessages.push({me:false,text:d.reply});render()}
function chat(){return top("Chat","YOUR AI ASSISTANT")+`<div class="chat"><div class="messages">${chatMessages.length?chatMessages.map(m=>`<div class="msg ${m.me?"me":"ai"}">${esc(m.text)}</div>`).join(""):`<div style="height:100%;display:grid;place-items:center;text-align:center"><div><div class="orb" style="width:64px;height:64px;font-size:25px">◈</div><h2>What are we working on?</h2><p class="muted">Ask ORIXA a question or give it a goal.</p></div></div>`}</div><div class="composer"><textarea id="chatInput" placeholder="Message ORIXA..." onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendFromComposer()}"></textarea><button class="send" onclick="sendFromComposer()">Send</button></div></div>`}
function sendFromComposer(){const v=document.getElementById("chatInput").value.trim();if(!v)return;chatMessages.push({me:true,text:v});render();setTimeout(sendChat,80)}
function toolPage(title,sub,cards){return top(title)+`<p class="sub">${sub}</p><div class="grid">${cards.map(c=>`<div class="card"><div class="tool-icon">${c[0]}</div><h3>${c[1]}</h3><p>${c[2]}</p><button class="ghost" onclick="toast('${c[1]} is ready to connect to the production AI service.')">Open</button></div>`).join("")}</div>`}
function create(){return toolPage("Create","Bring ideas to life with ORIXA's creative workspace.",[["🖼️","Image Creator","Generate visuals from your ideas."],["✍️","Writing Studio","Draft captions, scripts, stories and documents."],["🎨","Design","Create brand concepts and visual directions."],["💡","Idea Lab","Brainstorm and develop concepts together."]])}
function video(){return toolPage("Video Studio","Plan, generate and organize AI video projects.",[["🎬","Image → Video","Animate a still image into a scene."],["📝","Script Builder","Turn an idea into a scene-by-scene script."],["🎞️","Storyboard","Plan shots, camera movement and dialogue."],["📣","Ad Creator","Build product ads and social video concepts."]])}
function voice(){const voices=[["Nova","Female","American","Warm & friendly"],["Luna","Female","British","Soft & elegant"],["Zara","Female","Nigerian","Confident & energetic"],["Maya","Female","American","Bright & youthful"],["Aria","Female","Australian","Calm & sophisticated"],["Kai","Male","American","Calm & professional"],["Leo","Male","American","Deep & powerful"],["James","Male","British","Smooth & formal"],["Jay","Male","Nigerian","Friendly & expressive"],["Eli","Male","Australian","Relaxed & playful"]];return top("Voice Studio","SPEAK WITH ORIXA")+`<div class="hero" style="margin-bottom:20px"><h2 style="font-size:30px">Choose your voice.</h2><p>Preview all 10 voices, then customize accent, speed, pitch and emotion.</p><div class="grid" style="grid-template-columns:repeat(4,1fr)"><div class="card"><b>Accent</b><p class="muted">American · British · Nigerian · Australian · Canadian · Irish · South African · Indian</p></div><div class="card"><b>Speed</b><p class="muted">0.75× · 1× · 1.25× · 1.5×</p></div><div class="card"><b>Pitch</b><p class="muted">Lower · Normal · Higher</p></div><div class="card"><b>Emotion</b><p class="muted">Neutral · Happy · Calm · Excited · Serious</p></div></div></div><div class="voice-list">${voices.map(v=>`<div class="voice"><div><strong>🎙️ ${v[0]}</strong><small>${v[1]} · ${v[2]} · ${v[3]}</small></div><div class="voice-actions"><button class="ghost" onclick="toast('Previewing ${v[0]}')">▶ Preview</button><button class="primary" style="width:auto" onclick="toast('${v[0]} selected')">Use</button></div></div>`).join("")}</div>`}
function research(){return toolPage("Research","Organize information, sources and findings.",[["⌕","Deep Research","Break a complex question into a research workflow."],["🌐","Web Search","Gather current information from the web."],["📄","Source Reader","Summarize and compare documents."],["📊","Analysis","Turn research into structured findings."]])}
function learn(){return toolPage("Learn","Turn any subject into a personalized learning experience.",[["📚","Study Plan","Build a schedule around your goal."],["🧠","Tutor","Learn concepts step by step."],["🃏","Flashcards","Create and practice memory cards."],["✓","Quiz","Test your understanding and track progress."]])}
function work(){return toolPage("Work","Plan, write and organize real-world tasks.",[["📋","Planner","Turn goals into actionable tasks."],["📄","Documents","Draft and refine professional documents."],["📈","Projects","Break large goals into manageable milestones."],["🤝","Assistant","Get help completing a workflow."]])}
async function projects(){const r=await fetch("/api/projects");const ps=await r.json();return top("Projects","YOUR WORKSPACE")+`<div class="hero"><h2 style="font-size:28px">Everything you're building.</h2><p>Create spaces for brands, school, content, business and personal goals.</p><button class="primary" style="width:auto" onclick="newProject()">＋ New project</button></div><div class="list" style="margin-top:20px">${ps.map(p=>`<div class="list-row"><div><b>${esc(p.icon)} ${esc(p.name)}</b><div class="muted">${esc(p.type)} · ${esc(p.updated)}</div></div><button class="ghost" onclick="toast('Project workspace opened.')">Open</button></div>`).join("")}</div>`}
function newProject(){const name=prompt("Project name");if(!name)return;fetch("/api/projects",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name})}).then(()=>{toast("Project created.");render()})}
function library(){return top("Library","YOUR FILES")+`<div class="hero"><h2 style="font-size:28px">Your AI workspace.</h2><p>Files, generated content, saved research and project assets will live here.</p><button class="primary" style="width:auto" onclick="toast('File picker will connect here in production.')">＋ Add file</button></div><div class="list" style="margin-top:20px">${["ORIXA Brand Notes","Product Ad Script","Study Notes","Video Storyboard"].map((x,i)=>`<div class="list-row"><div><b>▤ ${x}</b><div class="muted">${i%2?"Document":"Project file"}</div></div><span class="pill">Saved</span></div>`).join("")}</div>`}
function settings(){return top("Settings","ORIXA PREFERENCES")+`<div class="settings"><div class="setting"><div><b>Profile</b><div class="muted">${esc(currentUser.email||"")}</div></div><button class="ghost" onclick="toast('Profile editor ready.')">Edit</button></div><div class="setting"><div><b>Appearance</b><div class="muted">Dark luxury interface</div></div><button class="ghost" onclick="toast('Theme controls coming next.')">Change</button></div><div class="setting"><div><b>Notifications</b><div class="muted">Project and assistant updates</div></div><button class="switch on"></button></div><div class="setting"><div><b>Privacy</b><div class="muted">Manage data and connected services</div></div><button class="ghost" onclick="toast('Privacy center ready.')">Open</button></div><div class="setting"><div><b>Log out</b><div class="muted">End this ORIXA session</div></div><button class="ghost" onclick="logout()">Log out</button></div></div>`}
function logout(){localStorage.removeItem("orixa_user");currentUser=null;screen="home";render()}
render();
if(currentUser && screen==="home")setTimeout(loadProjects,50);
