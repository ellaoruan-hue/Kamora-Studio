const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const state = {
  user: null,
  projects: [
    { id: 1, name: "Elane", type: "Brand", updated: "Today", icon: "✦" },
    { id: 2, name: "ORIXA Launch", type: "Business", updated: "Today", icon: "🚀" },
    { id: 3, name: "Study Plan", type: "Learning", updated: "Yesterday", icon: "📚" }
  ],
  files: []
};

app.get("/api/health", (_, res) => res.json({ ok: true, app: "ORIXA AI" }));

app.get("/api/projects", (_, res) => res.json(state.projects));

app.post("/api/auth/signup", (req, res) => {
  const { name, email } = req.body || {};
  if (!name || !email) return res.status(400).json({ error: "Name and email are required." });
  state.user = { name, email, preferences: req.body.preferences || [] };
  res.json({ ok: true, user: state.user });
});

app.post("/api/auth/login", (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ error: "Email is required." });
  state.user = { name: email.split("@")[0], email, preferences: [] };
  res.json({ ok: true, user: state.user });
});

app.post("/api/chat", (req, res) => {
  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "Message is required." });
  res.json({
    ok: true,
    reply: `I'm ORIXA. I understand you want to: "${message}". In the production version, this request will be routed to the appropriate AI capability and ORIXA will organize the next steps for you.`,
    suggestions: ["Turn this into a plan", "Create something", "Research it", "Save to a project"]
  });
});

app.post("/api/projects", (req, res) => {
  const project = {
    id: Date.now(),
    name: req.body?.name || "Untitled Project",
    type: req.body?.type || "Project",
    updated: "Just now",
    icon: req.body?.icon || "✦"
  };
  state.projects.unshift(project);
  res.json(project);
});

app.post("/api/files", (req, res) => {
  const file = { id: Date.now(), name: req.body?.name || "New file", type: req.body?.type || "File" };
  state.files.unshift(file);
  res.json(file);
});

app.get("/api/voice-options", (_, res) => {
  res.json([
    { name: "Nova", gender: "Female", accent: "American", style: "Warm & friendly" },
    { name: "Luna", gender: "Female", accent: "British", style: "Soft & elegant" },
    { name: "Zara", gender: "Female", accent: "Nigerian", style: "Confident & energetic" },
    { name: "Maya", gender: "Female", accent: "American", style: "Bright & youthful" },
    { name: "Aria", gender: "Female", accent: "Australian", style: "Calm & sophisticated" },
    { name: "Kai", gender: "Male", accent: "American", style: "Calm & professional" },
    { name: "Leo", gender: "Male", accent: "American", style: "Deep & powerful" },
    { name: "James", gender: "Male", accent: "British", style: "Smooth & formal" },
    { name: "Jay", gender: "Male", accent: "Nigerian", style: "Friendly & expressive" },
    { name: "Eli", gender: "Male", accent: "Australian", style: "Relaxed & playful" }
  ]);
});

app.get("*splat", (_, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`ORIXA AI running at http://localhost:${PORT}`));
