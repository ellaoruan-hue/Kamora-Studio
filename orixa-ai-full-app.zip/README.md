# ORIXA AI — Full App Foundation

## Run locally
1. Install Node.js LTS.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000

## Included
- Login / sign up
- Google / Apple demo buttons
- Personalization onboarding
- Home dashboard
- Chat interface + API
- Create workspace
- Video Studio
- Voice Studio with 10 voices, accents, speed, pitch and emotion controls
- Research
- Learn
- Work
- Projects
- Library
- Settings
- Express API foundation

## Important
The AI response in `/api/chat` is currently a demo placeholder. Production ORIXA should connect the server to a real model provider, database, authentication provider, file storage, image/video generation services, voice/TTS provider, web research layer, moderation, billing, and background jobs.

Never put secret API keys in `public/app.js`; keep them on the server.
