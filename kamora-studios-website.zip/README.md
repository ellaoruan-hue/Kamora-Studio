# Kamora Studios Website

A responsive single-page website for Kamora Studios.

## Brand
- Obsidian: #111111
- Mocha: #6B4A3A
- Dusty Rose: #B77B7F
- Antique Gold: #C8A96B
- Warm Cream: #F4EDE3

## Deploy
This is a static HTML/CSS/JS site. It can be deployed directly to Netlify or GitHub Pages.
